import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:consultancy_firm_app/models/business_tracker.dart';

part 'business_tracker_event.dart';
part 'business_tracker_state.dart';

class BusinessTrackerBloc
    extends Bloc<BusinessTrackerEvent, BusinessTrackerState> {
  BusinessTrackerBloc() : super(BusinessTrackerInitial());

  @override
  Stream<BusinessTrackerState> mapEventToState(
      BusinessTrackerEvent event) async* {
    if (event is LoadBusinessTrackers) {
      yield BusinessTrackerLoading();
      try {
        // Simulate fetching data from an API or database
        await Future.delayed(Duration(seconds: 2));
        final List<BusinessTracker> businessTrackers =
            []; // Replace with actual data fetching
        yield BusinessTrackersLoaded(businessTrackers: businessTrackers);
      } catch (e) {
        yield BusinessTrackerError(error: e.toString());
      }
    }
  }
}
