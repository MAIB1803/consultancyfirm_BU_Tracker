part of 'business_tracker_bloc.dart';

abstract class BusinessTrackerEvent extends Equatable {
  const BusinessTrackerEvent();

  @override
  List<Object> get props => [];
}

class LoadBusinessTrackers extends BusinessTrackerEvent {}
