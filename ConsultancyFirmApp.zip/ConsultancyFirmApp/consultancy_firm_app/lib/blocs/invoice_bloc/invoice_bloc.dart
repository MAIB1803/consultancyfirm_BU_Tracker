import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import '../../repositories/invoice_repository.dart';
import '../../models/invoice.dart';

// Events
part 'invoice_event.dart';

// States
part 'invoice_state.dart';

class InvoiceBloc extends Bloc<InvoiceEvent, InvoiceState> {
  final InvoiceRepository invoiceRepository;

  InvoiceBloc({required this.invoiceRepository}) : super(InvoiceInitial());

  @override
  Stream<InvoiceState> mapEventToState(InvoiceEvent event) async* {
    if (event is LoadInvoices) {
      yield InvoiceLoading();
      try {
        final invoices = await invoiceRepository.getAllInvoices();
        yield InvoicesLoaded(invoices: invoices);
      } catch (e) {
        yield InvoiceError(error: e.toString());
      }
    }
  }
}
