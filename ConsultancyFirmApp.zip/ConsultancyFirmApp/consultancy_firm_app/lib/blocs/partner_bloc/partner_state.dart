part of 'partner_bloc.dart';

abstract class PartnerState extends Equatable {
  const PartnerState();

  @override
  List<Object> get props => [];
}

class PartnerInitial extends PartnerState {}

class PartnerLoading extends PartnerState {}

class PartnersLoaded extends PartnerState {
  final List<Partner> partners;

  const PartnersLoaded({required this.partners});

  @override
  List<Object> get props => [partners];
}

class PartnerError extends PartnerState {
  final String error;

  const PartnerError({required this.error});

  @override
  List<Object> get props => [error];
}
