import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import '../../repositories/auth_repository.dart';
import '../../models/user.dart';

// Events
part 'auth_event.dart';

// States
part 'auth_state.dart';

class AuthBloc extends Bloc<AuthEvent, AuthState> {
  final AuthRepository authRepository;

  AuthBloc({required this.authRepository}) : super(AuthInitial());

  @override
  Stream<AuthState> mapEventToState(AuthEvent event) async* {
    if (event is AuthLoginRequested) {
      yield AuthLoading();
      try {
        final user = await authRepository.login(event.email, event.password);
        yield AuthSuccess(user: user);
      } catch (e) {
        yield AuthFailure(error: e.toString());
      }
    } else if (event is AuthLogoutRequested) {
      yield AuthInitial();
    }
  }
}
