const String apiUrl = 'https://your-api-url.com/api';
