import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'blocs/auth_bloc/auth_bloc.dart';
import 'blocs/partner_bloc/partner_bloc.dart';
import 'blocs/employee_bloc/employee_bloc.dart';
import 'blocs/business_tracker_bloc/business_tracker_bloc.dart';
import 'blocs/invoice_bloc/invoice_bloc.dart';
import 'repositories/auth_repository.dart';
import 'repositories/partner_repository.dart';
import 'repositories/employee_repository.dart';
import 'repositories/business_tracker_repository.dart';
import 'repositories/invoice_repository.dart';
import 'screens/login_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) => AuthBloc(authRepository: AuthRepository()),
        ),
        BlocProvider(
          create: (context) =>
              PartnerBloc(partnerRepository: PartnerRepository()),
        ),
        BlocProvider(
          create: (context) =>
              EmployeeBloc(employeeRepository: EmployeeRepository()),
        ),
        BlocProvider(
          create: (context) => BusinessTrackerBloc(
              businessTrackerRepository: BusinessTrackerRepository()),
        ),
        BlocProvider(
          create: (context) =>
              InvoiceBloc(invoiceRepository: InvoiceRepository()),
        ),
      ],
      child: MaterialApp(
        title: 'Consultancy Firm App',
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        home: LoginScreen(),
      ),
    );
  }
}
