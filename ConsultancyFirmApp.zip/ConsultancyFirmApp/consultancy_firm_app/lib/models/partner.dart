class Partner {
  final int partnerID;
  final String partnerName;
  final String contactInfo;
  final String address;
  final DateTime joinedDate;
  final String userId;

  Partner({
    required this.partnerID,
    required this.partnerName,
    required this.contactInfo,
    required this.address,
    required this.joinedDate,
    required this.userId,
  });

  factory Partner.fromJson(Map<String, dynamic> json) {
    return Partner(
      partnerID: json['partnerID'],
      partnerName: json['partnerName'],
      contactInfo: json['contactInfo'],
      address: json['address'],
      joinedDate: DateTime.parse(json['joinedDate']),
      userId: json['userId'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'partnerID': partnerID,
      'partnerName': partnerName,
      'contactInfo': contactInfo,
      'address': address,
      'joinedDate': joinedDate.toIso8601String(),
      'userId': userId,
    };
  }
}
