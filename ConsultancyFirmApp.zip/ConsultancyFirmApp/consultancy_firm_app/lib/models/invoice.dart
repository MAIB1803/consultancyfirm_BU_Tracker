class Invoice {
  final int invoiceID;
  final String invoiceNumber;
  final DateTime invoiceDate;
  final String clientName;
  final double amount;
  final String status;
  final int relatedProjectID;
  final String commentsNotes;

  Invoice({
    required this.invoiceID,
    required this.invoiceNumber,
    required this.invoiceDate,
    required this.clientName,
    required this.amount,
    required this.status,
    required this.relatedProjectID,
    required this.commentsNotes,
  });

  factory Invoice.fromJson(Map<String, dynamic> json) {
    return Invoice(
      invoiceID: json['invoiceID'],
      invoiceNumber: json['invoiceNumber'],
      invoiceDate: DateTime.parse(json['invoiceDate']),
      clientName: json['clientName'],
      amount: json['amount'],
      status: json['status'],
      relatedProjectID: json['relatedProjectID'],
      commentsNotes: json['commentsNotes'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'invoiceID': invoiceID,
      'invoiceNumber': invoiceNumber,
      'invoiceDate': invoiceDate.toIso8601String(),
      'clientName': clientName,
      'amount': amount,
      'status': status,
      'relatedProjectID': relatedProjectID,
      'commentsNotes': commentsNotes,
    };
  }
}
