import 'package:flutter/material.dart';
import '../widgets/dashboard_chart.dart';
import 'package:fl_chart/fl_chart.dart';

class DashboardScreen extends StatelessWidget {
  final List<FlSpot> dataPoints = [
    FlSpot(0, 1),
    FlSpot(1, 3),
    FlSpot(2, 7),
    FlSpot(3, 5),
    FlSpot(4, 8),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Dashboard'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text(
              'Business Metrics',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            DashboardChart(dataPoints: dataPoints),
          ],
        ),
      ),
    );
  }
}
