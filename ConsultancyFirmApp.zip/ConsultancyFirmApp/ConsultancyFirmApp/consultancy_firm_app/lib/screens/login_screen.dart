import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../blocs/auth_bloc/auth_bloc.dart';
import '../utils/helpers.dart';
import '../widgets/custom_button.dart';
import '../widgets/custom_input_field.dart';

class LoginScreen extends StatelessWidget {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            CustomInputField(
              label: 'Email',
              controller: emailController,
            ),
            CustomInputField(
              label: 'Password',
              controller: passwordController,
              isPassword: true,
            ),
            SizedBox(height: 20),
            BlocConsumer<AuthBloc, AuthState>(
              listener: (context, state) {
                if (state is AuthFailure) {
                  showSnackBar(context, state.error);
                } else if (state is AuthSuccess) {
                  Navigator.pushReplacementNamed(context, '/dashboard');
                }
              },
              builder: (context, state) {
                if (state is AuthLoading) {
                  return CircularProgressIndicator();
                }
                return CustomButton(
                  text: 'Login',
                  onPressed: () {
                    if (isValidEmail(emailController.text) &&
                        passwordController.text.isNotEmpty) {
                      BlocProvider.of<AuthBloc>(context).add(
                        AuthLoginRequested(
                          emailController.text,
                          passwordController.text,
                        ),
                      );
                    } else {
                      showSnackBar(context, 'Please enter valid email and password.');
                    }
                  },
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
