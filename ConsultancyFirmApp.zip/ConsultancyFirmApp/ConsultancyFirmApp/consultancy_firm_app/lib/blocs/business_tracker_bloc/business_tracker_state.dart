part of 'business_tracker_bloc.dart';

abstract class BusinessTrackerState extends Equatable {
  const BusinessTrackerState();

  @override
  List<Object> get props => [];
}

class BusinessTrackerInitial extends BusinessTrackerState {}

class BusinessTrackerLoading extends BusinessTrackerState {}

class BusinessTrackersLoaded extends BusinessTrackerState {
  final List<BusinessTracker> businessTrackers;

  const BusinessTrackersLoaded({required this.businessTrackers});

  @override
  List<Object> get props => [businessTrackers];
}

class BusinessTrackerError extends BusinessTrackerState {
  final String error;

  const BusinessTrackerError({required this.error});

  @override
  List<Object> get props => [error];
}
