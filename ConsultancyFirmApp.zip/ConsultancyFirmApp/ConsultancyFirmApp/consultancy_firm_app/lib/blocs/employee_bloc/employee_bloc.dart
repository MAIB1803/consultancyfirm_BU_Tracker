import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import '../../repositories/employee_repository.dart';
import '../../models/employee.dart';

// Events
part 'employee_event.dart';

// States
part 'employee_state.dart';

class EmployeeBloc extends Bloc<EmployeeEvent, EmployeeState> {
  final EmployeeRepository employeeRepository;

  EmployeeBloc({required this.employeeRepository}) : super(EmployeeInitial());

  @override
  Stream<EmployeeState> mapEventToState(EmployeeEvent event) async* {
    if (event is LoadEmployees) {
      yield EmployeeLoading();
      try {
        final employees = await employeeRepository.getAllEmployees();
        yield EmployeesLoaded(employees: employees);
      } catch (e) {
        yield EmployeeError(error: e.toString());
      }
    }
  }
}
