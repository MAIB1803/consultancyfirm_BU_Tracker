import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import '../../models/user.dart';
import '../../repositories/auth_repository.dart';

part 'auth_event.dart';
part 'auth_state.dart';

class AuthBloc extends Bloc<AuthEvent, AuthState> {
  final AuthRepository authRepository;

  AuthBloc({required this.authRepository}) : super(AuthInitial());

  @override
  Stream<AuthState> mapEventToState(AuthEvent event) async* {
    if (event is AuthLoginRequested) {
      yield AuthLoading();
      try {
        User user = await authRepository.login(event.email, event.password);
        yield AuthSuccess(user);
      } catch (error) {
        yield AuthFailure(error.toString());
      }
    } else if (event is AuthLogoutRequested) {
      yield AuthInitial();
    }
  }
}
