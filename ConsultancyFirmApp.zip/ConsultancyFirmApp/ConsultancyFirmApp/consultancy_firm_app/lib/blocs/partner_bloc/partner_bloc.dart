import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import '../../repositories/partner_repository.dart';
import '../../models/partner.dart';

// Events
part 'partner_event.dart';

// States
part 'partner_state.dart';

class PartnerBloc extends Bloc<PartnerEvent, PartnerState> {
  final PartnerRepository partnerRepository;

  PartnerBloc({required this.partnerRepository}) : super(PartnerInitial());

  @override
  Stream<PartnerState> mapEventToState(PartnerEvent event) async* {
    if (event is LoadPartners) {
      yield PartnerLoading();
      try {
        final partners = await partnerRepository.getAllPartners();
        yield PartnersLoaded(partners: partners);
      } catch (e) {
        yield PartnerError(error: e.toString());
      }
    }
  }
}
