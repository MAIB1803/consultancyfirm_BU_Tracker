class BusinessTracker {
  final int trackerID;
  final int partnerID;
  final DateTime date;
  final String clientName;
  final String projectName;
  final String industryType;
  final String projectStatus;
  final String projectDirectorManager;
  final DateTime startDate;
  final DateTime endDate;
  final String leadSource;
  final String leadStatus;
  final double estimatedValue;
  final DateTime expectedDealCloseDate;
  final String taskDescription;
  final int billableHours;
  final String commentsNotes;

  BusinessTracker({
    required this.trackerID,
    required this.partnerID,
    required this.date,
    required this.clientName,
    required this.projectName,
    required this.industryType,
    required this.projectStatus,
    required this.projectDirectorManager,
    required this.startDate,
    required this.endDate,
    required this.leadSource,
    required this.leadStatus,
    required this.estimatedValue,
    required this.expectedDealCloseDate,
    required this.taskDescription,
    required this.billableHours,
    required this.commentsNotes,
  });

  factory BusinessTracker.fromJson(Map<String, dynamic> json) {
    return BusinessTracker(
      trackerID: json['trackerID'],
      partnerID: json['partnerID'],
      date: DateTime.parse(json['date']),
      clientName: json['clientName'],
      projectName: json['projectName'],
      industryType: json['industryType'],
      projectStatus: json['projectStatus'],
      projectDirectorManager: json['projectDirectorManager'],
      startDate: DateTime.parse(json['startDate']),
      endDate: DateTime.parse(json['endDate']),
      leadSource: json['leadSource'],
      leadStatus: json['leadStatus'],
      estimatedValue: json['estimatedValue'],
      expectedDealCloseDate: DateTime.parse(json['expectedDealCloseDate']),
      taskDescription: json['taskDescription'],
      billableHours: json['billableHours'],
      commentsNotes: json['commentsNotes'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'trackerID': trackerID,
      'partnerID': partnerID,
      'date': date.toIso8601String(),
      'clientName': clientName,
      'projectName': projectName,
      'industryType': industryType,
      'projectStatus': projectStatus,
      'projectDirectorManager': projectDirectorManager,
      'startDate': startDate.toIso8601String(),
      'endDate': endDate.toIso8601String(),
      'leadSource': leadSource,
      'leadStatus': leadStatus,
      'estimatedValue': estimatedValue,
      'expectedDealCloseDate': expectedDealCloseDate.toIso8601String(),
      'taskDescription': taskDescription,
      'billableHours': billableHours,
      'commentsNotes': commentsNotes,
    };
  }
}
