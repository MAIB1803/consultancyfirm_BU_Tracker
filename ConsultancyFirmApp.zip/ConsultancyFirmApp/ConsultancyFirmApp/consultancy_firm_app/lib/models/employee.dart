class Employee {
  final int employeeID;
  final String employeeName;
  final String position;
  final String contactInfo;
  final DateTime hiredDate;
  final String userId;

  Employee({
    required this.employeeID,
    required this.employeeName,
    required this.position,
    required this.contactInfo,
    required this.hiredDate,
    required this.userId,
  });

  factory Employee.fromJson(Map<String, dynamic> json) {
    return Employee(
      employeeID: json['employeeID'],
      employeeName: json['employeeName'],
      position: json['position'],
      contactInfo: json['contactInfo'],
      hiredDate: DateTime.parse(json['hiredDate']),
      userId: json['userId'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'employeeID': employeeID,
      'employeeName': employeeName,
      'position': position,
      'contactInfo': contactInfo,
      'hiredDate': hiredDate.toIso8601String(),
      'userId': userId,
    };
  }
}
