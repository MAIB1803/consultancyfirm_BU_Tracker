import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/employee.dart';

class EmployeeRepository {
  final String baseUrl = 'https://your-api-url.com/api';

  Future<List<Employee>> getAllEmployees() async {
    final response = await http.get(
      Uri.parse('$baseUrl/employees'),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
    );

    if (response.statusCode == 200) {
      Iterable l = json.decode(response.body);
      return List<Employee>.from(l.map((model) => Employee.fromJson(model)));
    } else {
      throw Exception('Failed to load employees');
    }
  }
}
