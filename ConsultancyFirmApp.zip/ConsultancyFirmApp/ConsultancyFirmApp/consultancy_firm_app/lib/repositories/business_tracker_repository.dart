import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/business_tracker.dart';

class BusinessTrackerRepository {
  final String baseUrl = 'https://your-api-url.com/api';

  Future<List<BusinessTracker>> getAllBusinessTrackers() async {
    final response = await http.get(
      Uri.parse('$baseUrl/business_trackers'),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
    );

    if (response.statusCode == 200) {
      Iterable l = json.decode(response.body);
      return List<BusinessTracker>.from(l.map((model) => BusinessTracker.fromJson(model)));
    } else {
      throw Exception('Failed to load business trackers');
    }
  }
}
