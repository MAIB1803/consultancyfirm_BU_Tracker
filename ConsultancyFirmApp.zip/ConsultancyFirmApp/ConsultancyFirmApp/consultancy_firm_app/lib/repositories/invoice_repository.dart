import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/invoice.dart';

class InvoiceRepository {
  final String baseUrl = 'https://your-api-url.com/api';

  Future<List<Invoice>> getAllInvoices() async {
    final response = await http.get(
      Uri.parse('$baseUrl/invoices'),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
    );

    if (response.statusCode == 200) {
      Iterable l = json.decode(response.body);
      return List<Invoice>.from(l.map((model) => Invoice.fromJson(model)));
    } else {
      throw Exception('Failed to load invoices');
    }
  }
}
