import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/partner.dart';

class PartnerRepository {
  final String baseUrl = 'https://your-api-url.com/api';

  Future<List<Partner>> getAllPartners() async {
    final response = await http.get(
      Uri.parse('$baseUrl/partners'),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
    );

    if (response.statusCode == 200) {
      Iterable l = json.decode(response.body);
      return List<Partner>.from(l.map((model) => Partner.fromJson(model)));
    } else {
      throw Exception('Failed to load partners');
    }
  }
}
