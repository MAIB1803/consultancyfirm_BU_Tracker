export 'src/flutter_secure_storage_windows_stub.dart'
    if (dart.library.ffi) 'src/flutter_secure_storage_windows_ffi.dart'
    show FlutterSecureStorageWindows;
